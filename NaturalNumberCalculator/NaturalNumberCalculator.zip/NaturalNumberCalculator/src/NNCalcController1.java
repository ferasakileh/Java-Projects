import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Feras Akileh
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model,
            NNCalcView view) {

        // derive top and bottom number from model
        NaturalNumber topNum = model.top();
        NaturalNumber bottomNum = model.bottom();

        // updates the availability of the subtract button
        if (bottomNum.compareTo(topNum) > 0) {
            view.updateSubtractAllowed(false);
        } else {
            view.updateSubtractAllowed(true);
        }

        // updates the availability of the divide button
        if (bottomNum.isZero()) {
            view.updateDivideAllowed(false);
        } else {
            view.updateDivideAllowed(true);
        }

        // updates the availability of the power button
        if (bottomNum.compareTo(INT_LIMIT) <= 0) {
            view.updatePowerAllowed(true);
        } else {
            view.updatePowerAllowed(false);
        }

        // updates the availability of the root button
        if (bottomNum.compareTo(TWO) >= 0
                && bottomNum.compareTo(INT_LIMIT) <= 0) {
            view.updateRootAllowed(true);
        } else {
            view.updateRootAllowed(false);
        }

        // updates the view
        view.updateTopDisplay(topNum);
        view.updateBottomDisplay(bottomNum);

    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {

        // initializes model and view
        this.model = model;
        this.view = view;

        // calls updateViewToMatchModel
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {

        // derive numbers from model
        NaturalNumber topNum = this.model.top();
        NaturalNumber bottomNum = this.model.bottom();

        // updates the numbers
        topNum.copyFrom(bottomNum);

        // updates view
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddEvent() {

        // derive numbers from model
        NaturalNumber topNum = this.model.top();
        NaturalNumber bottomNum = this.model.bottom();

        // performs the addition
        bottomNum.add(topNum);
        topNum.clear();

        // updates view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processSubtractEvent() {

        // derive numbers from model
        NaturalNumber topNum = this.model.top();
        NaturalNumber bottomNum = this.model.bottom();

        // performs the subtraction
        topNum.subtract(bottomNum);
        bottomNum.transferFrom(topNum);

        // updates view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processMultiplyEvent() {

        // derive numbers from model
        NaturalNumber topNum = this.model.top();
        NaturalNumber bottomNum = this.model.bottom();

        // performs the multiplication
        topNum.multiply(bottomNum);
        bottomNum.transferFrom(topNum);

        // updates view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processDivideEvent() {

        // derive numbers from model
        NaturalNumber topNum = this.model.top();
        NaturalNumber bottomNum = this.model.bottom();

        // performs the division
        NaturalNumber dividend = topNum.divide(bottomNum);
        bottomNum.transferFrom(topNum);
        topNum.transferFrom(dividend);

        // updates view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processPowerEvent() {

        // derive numbers from model
        NaturalNumber topNum = this.model.top();
        NaturalNumber bottomNum = this.model.bottom();

        // performs the power function
        topNum.power(bottomNum.toInt());
        bottomNum.transferFrom(topNum);

        // updates view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processRootEvent() {

        // derive numbers from model
        NaturalNumber topNum = this.model.top();
        NaturalNumber bottomNum = this.model.bottom();

        // performs the root function
        topNum.root(bottomNum.toInt());
        bottomNum.transferFrom(topNum);

        // updates view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processAddNewDigitEvent(int digit) {

        // derives the number
        NaturalNumber bottomNum = this.model.bottom();

        // adds the digit
        bottomNum.multiplyBy10(digit);

        // updates view
        updateViewToMatchModel(this.model, this.view);

    }

}
