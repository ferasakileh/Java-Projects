import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.Reporter;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code int}.
 *
 * @author Feras Akileh
 *
 */
public final class XMLTreeNNExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeNNExpressionEvaluator() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static NaturalNumber evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";

        // initializes the variable for one
        NaturalNumber one = new NaturalNumber2(1);

        // initializes the string for the exp.label()
        String expLabel = exp.label();

        // checks for the multiplication in the tree
        if (expLabel.equals("times")) {
            NaturalNumber childA = evaluate(exp.child(0));
            childA.multiply(evaluate(exp.child(1)));
            return childA;
        }

        // checks for the addition in the tree
        if (expLabel.equals("plus")) {
            NaturalNumber childA = evaluate(exp.child(0));
            childA.add(evaluate(exp.child(1)));
            return childA;
        }

        // checks for the division in the tree
        if (expLabel.equals("divide")) {
            NaturalNumber childA = evaluate(exp.child(0));
            NaturalNumber childB = evaluate(exp.child(1));
            if (childB.canConvertToInt() && childB.toInt() == 0) {
                Reporter.fatalErrorToConsole("Sorry! You cannot divide by 0!");
            }
            childA.divide(childB);
            return childA;
        }

        // checks for the subtraction in the tree
        if (expLabel.equals("minus")) {
            NaturalNumber childA = evaluate(exp.child(0));
            NaturalNumber childB = evaluate(exp.child(1));
            if (childB.compareTo(childA) > 0) {
                Reporter.fatalErrorToConsole("Sorry! You cannot divide by 0!");
            }
            childA.subtract(childB);
            return childA;
        }

        // checks for the numbers in the tree
        if (expLabel.equals("number")) {
            NaturalNumber m = new NaturalNumber2(exp.attributeValue("value"));
            return m;
        } else {
            return one;
        }

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}