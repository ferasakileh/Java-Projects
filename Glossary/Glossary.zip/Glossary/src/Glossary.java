import components.map.Map;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * This program will create an index page of many terms and will provide
 * separate pages for their definitions given an input file.
 *
 * @author Feras Akileh
 *
 */
public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * Adds the terms and definitions to two sequences
     *
     * @param in
     *            the input stream
     * @param termsMap
     *            the map that will contain the terms and their definitions
     * @param termsSet
     *            a set that contains just the terms
     */
    private static void deriveTermsAndDefs(SimpleReader in,
            Map<String, String> termsMap, Set<String> termsSet) {

        // creates a while loop that scans the input file
        while (!in.atEOS()) {

            // initializes variables for the term and definition
            String term = "";
            String definition = "";

            // creates a boolean variable that changes depending on if the
            // stream has an empty line
            boolean hasEmptyLine = true;

            // initializes a variable for the current line that the reader
            // is working on
            String current = in.nextLine();

            if (current.equals("")) {
                hasEmptyLine = false;
            } else {
                term = current;
            }

            while (hasEmptyLine && !in.atEOS()) {

                current = in.nextLine();

                if (!current.equals("")) {
                    definition = definition + " " + current;
                } else {
                    hasEmptyLine = false;
                }
            }

            // adds terms and definitions to the map and terms set
            termsMap.add(term, definition);
            termsSet.add(term);

        }

    }

    /**
     * Takes the set of terms and puts them in alphabetical order
     *
     * @param termsSet
     *            the set of terms
     *
     * @replaces termsSet
     *
     * @ensures terms = original terms set without word that is the earliest in
     *          the alphabet
     *
     */
    private static String alphabetize(Set<String> termsSet) {

        // creates a duplicate set of termsSet
        Set<String> termsSet2 = new Set1L<>();

        // initializes the string that will be returned
        String result = "";

        // initializes a while loop that checks the terms in the set
        while (termsSet.size() > 0 && result.equals("")) {

            int index = 0;
            String test = termsSet.removeAny();

            for (String word : termsSet) {
                if (word.compareTo(test) < 0) {
                    index++;
                }
            }
            if (index == 0) {
                result = test;
            } else {
                termsSet2.add(test);
            }
        }

        termsSet.add(termsSet2);
        return result;

    }

    /**
     * Generates the home page of the output HTML file.
     *
     * @param out
     *            the output stream
     * @param termsList
     *            the sequence of terms in alphabetical order
     * @param termsMap
     *            the map of the terms with their definitions
     * @param termArray
     *            an array of the list of terms
     * @param outPut
     *            the output file location
     */
    private static void generateIndex(SimpleWriter out,
            Sequence<String> termsList, Map<String, String> termsMap,
            String[] termArray, String outPut) {

        // creates new output file
        String index = outPut + "/index.html";
        SimpleWriter indexHome = new SimpleWriter1L(index);

        // writes HTML code for the index page
        indexHome.println("<html>");
        indexHome.println("<head>");
        indexHome.println("<title>" + "Glossary" + "</title>");
        indexHome.println("</head>");

        indexHome.println("<body>");
        indexHome.println(
                "<p style=\"font-size:32pt;\"><Strong>Glossary</Strong></p>");
        indexHome.println();
        indexHome.println(
                "<p style=\"font-size:18pt;\"><Strong>Index</Strong></p>");

        indexHome.println("<ul>");

        // initializes a while loop that creates the html pages
        while (termsList.length() > 0) {
            String word = termsList.remove(0);
            generateTermPage(word, out, termsMap, termArray, outPut);
            indexHome.println(
                    "<li><a href=\"" + word + ".html\">" + word + "</a></li>");
        }

        // writes html code to finish the home page
        indexHome.println("</ul>");
        indexHome.println("</body>");
        indexHome.println("</html>");

        // closes stream
        indexHome.close();

    }

    /**
     * Generates the page for the individual term
     *
     * @param word
     *            the term the page is created around
     * @param out
     *            the output stream
     * @param termsMap
     *            the map of the terms with their definitions
     * @param termArray
     *            an array of the list of terms
     * @param outPut
     *            the output file location
     */
    private static void generateTermPage(String word, SimpleWriter out,
            Map<String, String> termsMap, String[] termArray, String outPut) {

        /*
         * Generates string with location of the file as well as the html file's
         * page
         */
        String termPage = outPut + "/" + word + ".html";
        SimpleWriter webPage = new SimpleWriter1L(termPage);

        webPage.println("<html>");
        webPage.println("<head>");
        webPage.println("<title>" + word + "</title>");
        webPage.println("</head>");
        webPage.println("<body>");
        webPage.println("<p style=\"font-size:18pt;color:red;\"><b><i>" + word
                + "</b></i></p>");
        webPage.println();

        String definition = termsMap.value(word);
        Set<Character> separatorSet = new Set1L<>();
        String separators = " ,";

        generateElements(separators, separatorSet);

        String pageFeed = "";

        int i = 0;
        while (i < definition.length()) {
            String item = nextWordOrSeparator(definition, i, separatorSet);
            if (separatorSet.contains(item.charAt(0))) {
                pageFeed = pageFeed + item;
            } else {
                int c = 0;
                int count = 0;
                while (c < termArray.length) {
                    if (item.equals(termArray[c])) {
                        pageFeed = pageFeed + "<a href=\"" + termArray[c]
                                + ".html\">" + item + "</a>";
                        count++;
                    }
                    c++;
                }
                if (count == 0) {
                    pageFeed = pageFeed + item;
                }
            }
            i += item.length();
        }

        webPage.println("<p style=\"text-align:left;\">" + pageFeed + "</p>");
        webPage.println();
        webPage.println("Return to <a href=\"index.html\">index</a>");
        webPage.println("</body>");
        webPage.println("</html>");

        webPage.close();
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @ensures strSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> strSet) {
        assert str != null : "Violation of: str is not null";
        assert strSet != null : "Violation of: strSet is not null";

        int i = str.length();

        while (i > 0) {
            char x = str.charAt(i - 1);
            if (!strSet.contains(x)) {
                strSet.add(x);
            }
            i--;
        }

    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        char charTest = text.charAt(position);
        String result = "" + charTest;
        boolean sepContain = separators.contains(charTest);
        int endStr = position;

        if (sepContain) {
            endStr++;
            if (endStr <= text.length()) {
                charTest = text.charAt(endStr);
                while (separators.contains(charTest)) {

                    if (!separators.contains(charTest)) {
                        sepContain = false;
                    }
                    endStr++;
                    charTest = text.charAt(endStr);
                }
            }

        } else {
            endStr++;
            if (endStr < text.length()) {
                charTest = text.charAt(endStr);

                while (!separators.contains(charTest)
                        && endStr != text.length()) {

                    if (separators.contains(charTest)) {
                        sepContain = true;
                    }
                    endStr++;
                    if (endStr < text.length()) {
                        charTest = text.charAt(endStr);
                    }
                }
            }
        }

        result = text.substring(position, endStr);

        return result;

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {

        // initializes input and output streams
        SimpleWriter out = new SimpleWriter1L();
        SimpleReader in = new SimpleReader1L();

        // prompts the user for an input file
        out.println("Please provide an input file: ");
        String inPut = in.nextLine();
        SimpleReader inFile = new SimpleReader1L(inPut);

        // prompts the user for a folder in which to save the output pages
        out.println("Please provide a folder: ");
        String outPut = in.nextLine();

        // creates a map that will have the terms and their definitions
        Map<String, String> termsMap = new Map1L<>();
        Set<String> termsSet = new Set1L<>();

        // calls deriveTermsAndDefs
        deriveTermsAndDefs(inFile, termsMap, termsSet);

        Sequence<String> termsList = new Sequence1L<>();
        String[] termArray = new String[termsSet.size()];

        int i = 0;
        while (0 < termsSet.size()) {
            String nextTerm = alphabetize(termsSet);
            termsList.add(termsList.length(), nextTerm);
            termArray[i] = nextTerm;
            i++;
        }

        // calls generateIndex
        generateIndex(out, termsList, termsMap, termArray, outPut);

        // closes streams
        in.close();
        out.close();

    }

}
